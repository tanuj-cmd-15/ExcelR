public class Comments {
    public static void main(String[] args) {
        // Single line comments

        /*Multiline 
         * 
         * comments
         */
    }
}
