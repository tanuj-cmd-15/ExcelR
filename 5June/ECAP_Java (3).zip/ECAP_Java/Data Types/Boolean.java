

public class Boolean {
   public static void main(String[] args) {
    boolean isBool= true;
    boolean isboolean = false;
    System.out.println(isBool);
    System.out.println(isboolean);
   } 
}
