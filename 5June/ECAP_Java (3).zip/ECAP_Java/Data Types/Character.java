public class Character {
    public static void main(String[] args) {

        //Char type
        char myGrade = 'B';
        System.out.println(myGrade);

        //String type - group of chars
        String str = "Hello World!";
        System.out.println(str);

    }
}
