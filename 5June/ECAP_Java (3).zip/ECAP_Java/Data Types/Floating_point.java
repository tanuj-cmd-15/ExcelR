

public class Floating_point {
    public static void main(String[] args) {
        //Float type - six to seven decimal points
        float myFloat = 4.89f;
        System.out.println(myFloat);

        //Double type -  15 digits decimal points
        double myNum = 19.99d;
        System.out.println(myNum);

    }
}
