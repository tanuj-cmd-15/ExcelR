

public class Integer {
        public static void main(String[] args) {
            //Integer Data type

            // byte type
            byte myNum = 100;
            System.out.println(myNum);

            //short type
            short myNum2 = 5000;
            System.out.println(myNum2);

            //int type 
            int myNum3 = 100000;
            System.out.println(myNum3);

            //long type
            long myNum4 = 1500000000L;
            System.out.println(myNum4);


        }
}
