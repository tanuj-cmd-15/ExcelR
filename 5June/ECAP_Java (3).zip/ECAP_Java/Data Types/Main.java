public class Main {
    public static void main(String[] args)
    {
        String greeting = "Good Evening!";
        System.out.println(greeting);

    }
}