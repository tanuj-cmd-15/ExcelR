import java.io.*;
import java.util.*;

public class Main1 {
    public static void main(String[] args) {
        //Integer array
        int[] myNum = {10,20,30,40,50};
        System.out.println(myNum[1]);

        //String array
        String[] myFruits = {"Apple","Banana","Mango","Pinapple"};
        String myArray = Arrays.toString(myFruits);

        System.out.println(myArray);
    }
}
