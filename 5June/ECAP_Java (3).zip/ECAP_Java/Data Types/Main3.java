public class Main3 {
    int x = 5;
    public static void main(String[] args) {
       Main3 myObj = new Main3();
       System.out.println(myObj.x);
    }
}
