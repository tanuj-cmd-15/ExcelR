public class Java_Example{
public static void main(String[] args){
System.out.println("Welcome to Java!");
System.out.println("Welcome to Javascript!");

System.out.println(100);
System.out.println(10+20);

System.out.print("Welcome to Java!");
System.out.print("Welcome to Java!");
}
}
