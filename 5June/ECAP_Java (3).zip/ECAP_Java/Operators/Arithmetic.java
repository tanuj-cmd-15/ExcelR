public class Arithmetic{
    public static void main(String[] args) {
        int x = 10, y = 20;

        //Addition operation
        System.out.println(x+y); // 30

         //Substraction operation
         System.out.println(x-y);

         //Multiplication
         System.out.println(x*y);

         //Division

         System.out.println(x/y);

         //Modulus

         System.out.println(x%y);

         //Increment / Decrement
         System.out.println(x++);
         System.out.println(x);
         System.out.println(--y);
    
        }
}