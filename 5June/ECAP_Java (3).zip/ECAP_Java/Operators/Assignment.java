public class Assignment {
    public static void main(String[] args) {
        //Assignment =
        int x =10;
        int y = x;

        //Assignment +=
        x+=5;
        System.out.println(x);

        //Assignme -=
        x-=5;
        System.out.println(x);

        //Assignment *=
        x*=5;
        System.out.println(x);

        //Assignment /=

        x/=5;
        System.out.println(x);

        //Assignment %=

        // x%=5;
        // System.out.println(x);


        //Assignment &=
        int z=11;
        z&=1;
        System.out.println(z);

        //Assignment |=
        x|=1;
        System.out.println(x);

        //Assignment ^= 
        x^=3;
        System.out.println(x);
       


    }
}
