public class Comparison {
    public static void main(String[] args) {
        // comparison ==

        int x=20,y=20;
        System.out.println(x==y);

        //Comparison !=

        System.out.println(x!=y);

        //Greater than >
        System.out.println(x>y);

        //Smaller than <
        System.out.println(x<y);

        //Greater than or equal to
        System.out.println(x>=y);

        //Smaller than or equal to
        System.out.println(x<=y);

    }
}
