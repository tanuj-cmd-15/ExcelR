

public class Variables {
    public static void main(String[] args) {
        // String Variable

        String firstName = "John"; 
        String lastName = "Doe";
        System.out.println("Hello" + firstName+lastName);

        //Integer variable
        int num = 789;
        int num2 = 10;
        System.out.println(num+num2);

        // Float variable
        float num_Decimal = 29.89f;
        System.out.println(num_Decimal);

        //char variable
        char character = 'B';
        System.out.println(character);

        //boolean variable
        boolean myBool = true;
        System.out.println(myBool);

        //Multiple variable declaration
        int x =0,y=0,z=0;

        // One value to multiple variables
        x = y = z = 10;
        System.out.println(x+y+z);
    }
}
